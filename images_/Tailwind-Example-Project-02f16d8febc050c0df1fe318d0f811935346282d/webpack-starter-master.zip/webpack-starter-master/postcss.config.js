module.exports = {
    plugins: [
        require('tailwindcss')('./tailwind.js')
    ]
}
